import React, { useState, useEffect } from 'react';
import CanvasBackground from './components/CanvasBackground';
import ThemeToggle from './components/ThemeToggle';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Projects from './components/Projects';
import About from './components/About';
import Contact from './components/Contact';
import Footer from './components/Footer';

const App = () => {
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isVisible, setIsVisible] = useState({});
  const [currentProject, setCurrentProject] = useState(0);

  const projects = [
    {
      id: 1,
      title: 'Portfolio Website',
      description: 'A personal portfolio showcasing my projects and skills.',
      image: '/images/portfolio.png',
      tech: ['React', 'Tailwind CSS', 'JavaScript'],
      live: 'https://your-portfolio-link.com',
      github: 'https://github.com/yourname/portfolio',
    },
    {
      id: 2,
      title: 'E-commerce Store',
      description: 'A modern e-commerce store built with MERN stack.',
      image: '/images/ecommerce.png',
      tech: ['MongoDB', 'Express', 'React', 'Node.js'],
      live: 'https://your-store-link.com',
      github: 'https://github.com/yourname/ecommerce-store',
    },
    // Add more projects as needed
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible((prev) => ({
              ...prev,
              [entry.target.id]: true,
            }));
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('[data-animate]').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const prevProject = () => {
    setCurrentProject((prev) => (prev - 1 + projects.length) % projects.length);
  };

  const nextProject = () => {
    setCurrentProject((prev) => (prev + 1) % projects.length);
  };

  return (
    <div className={`relative min-h-screen overflow-x-hidden`}>
      <CanvasBackground isDarkMode={isDarkMode} />

      {/* Overlay gradient for dark/light */}
      <div
        className={`absolute inset-0 z-0 transition-all duration-1000 ${isDarkMode
            ? 'bg-gradient-to-br from-[#0f0f1a] via-[#0b0b13] to-[#1a1a2e]'
            : 'bg-gradient-to-br from-[#fff0f5] via-[#ffe4ec] to-[#ffd6e8]'
          }`}
      />

      {/* Content wrapper (must be relative and above) */}
      <div className="relative z-10">
        <ThemeToggle isDarkMode={isDarkMode} setIsDarkMode={setIsDarkMode} />
        <Navbar />
        <Hero isVisible={isVisible} />
        <Projects
          projects={projects}
          currentProject={currentProject}
          setCurrentProject={setCurrentProject}
          isVisible={isVisible}
          prevProject={prevProject}
          nextProject={nextProject}
        />
        <About />
        <Contact />
        <Footer />
      </div>
    </div>

  );
};

export default App;
