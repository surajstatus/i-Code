// src/components/About.jsx
import React from 'react';

const About = () => {
  const skills = {
    frontend: ['React', 'Vue.js', 'TypeScript', 'TailwindCSS'],
    backend: ['Node.js', 'Python', 'PostgreSQL', 'MongoDB'],
    tools: ['Git', 'Docker', 'AWS', 'Figma']
  };

  const renderSkillGroup = (title, skillsArray, colorClass) => (
    <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10 hover:bg-white/10 transition-all">
      <h3 className="text-2xl font-bold mb-6 text-center">{title}</h3>
      <div className="space-y-4">
        {skillsArray.map((skill) => (
          <div key={skill} className="flex items-center justify-between">
            <span>{skill}</span>
            <div className="w-24 h-2 bg-white/20 rounded-full overflow-hidden">
              <div
                className={`h-full bg-gradient-to-r ${colorClass} rounded-full`}
                style={{ width: `${80 + Math.random() * 20}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <section id="about" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent mb-4">
            About Me
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            I'm a passionate full-stack developer with expertise in modern web technologies. 
            I love creating beautiful, functional applications that solve real-world problems.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {renderSkillGroup('Frontend', skills.frontend, 'from-blue-500 to-purple-600')}
          {renderSkillGroup('Backend', skills.backend, 'from-green-500 to-blue-600')}
          {renderSkillGroup('Tools', skills.tools, 'from-purple-500 to-pink-600')}
        </div>
      </div>
    </section>
  );
};

export default About;
