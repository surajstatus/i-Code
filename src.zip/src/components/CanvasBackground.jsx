// src/components/CanvasBackground.jsx
import React, { useCallback } from 'react';
import { Particles } from '@tsparticles/react';
import { loadAll } from '@tsparticles/all';
import flower from '../assets/flower.png'; // Make sure this exists

const CanvasBackground = ({ isDarkMode }) => {
  const particlesInit = useCallback(async (engine) => {
    await loadAll(engine);
  }, []);

  return (
    <Particles
      id="tsparticles"
      init={particlesInit}
      options={{
        fullScreen: { enable: true, zIndex: -1 },
        background: { color: { value: 'transparent' } },
        particles: {
          number: { value: isDarkMode ? 100 : 30 },
          color: { value: isDarkMode ? '#ffffff' : '#ff69b4' },
          shape: {
            type: isDarkMode ? 'circle' : 'image',
            image: !isDarkMode ? [{ src: flower, width: 30, height: 30 }] : [],
          },
          size: { value: isDarkMode ? 2 : 6, random: true },
          move: {
            direction: 'bottom',
            speed: 1,
            outModes: { default: 'out' },
          },
          opacity: { value: 0.6 },
        },
        detectRetina: true,
      }}
    />
  );
};

export default CanvasBackground;
