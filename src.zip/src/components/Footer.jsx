// src/components/Footer.jsx
import React from 'react';

const Footer = () => {
  return (
    <footer className="py-12 border-t border-white/10 bg-black/10 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <p className="text-gray-400 text-sm">
          © {new Date().getFullYear()} Suraj Vishwakarma. All rights reserved. Built with ❤️ using React, TailwindCSS, and Lucide.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
