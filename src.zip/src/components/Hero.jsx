import React from 'react';
import { Code, Palette, Database, Globe } from 'lucide-react';

const Hero = ({ isVisible, scrollToSection }) => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-20">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Image */}
        <div className={`relative ${isVisible['hero-image'] ? 'animate-fade-in-left' : 'opacity-0'}`} id="hero-image" data-animate>
          <img
            src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face"
            alt="Profile"
            className="rounded-3xl shadow-2xl w-full max-w-md"
          />
        </div>

        {/* Content */}
        <div className={`space-y-8 ${isVisible['hero-content'] ? 'animate-fade-in-right' : 'opacity-0'}`} id="hero-content" data-animate>
          <h1 className="text-5xl lg:text-7xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent font-['Playfair_Display']">
            Hi, I'm John
          </h1>
          <h2 className="text-2xl lg:text-3xl text-gray-300">Full Stack Developer</h2>
          <p className="text-lg text-gray-400 leading-relaxed">
            Passionate about creating modern web applications with React, Node.js, and cloud solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button onClick={() => scrollToSection('projects')} className="bg-gradient-to-r from-blue-500 to-purple-600 px-8 py-3 rounded-full">
              View My Work
            </button>
            <button onClick={() => scrollToSection('contact')} className="border border-white/30 px-8 py-3 rounded-full">
              Get In Touch
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
