// src/components/ThemeToggle.jsx
import React from 'react';
import { Sun, Moon } from 'lucide-react';

const ThemeToggle = ({ isDarkMode, setIsDarkMode }) => {
  return (
    <button
      onClick={() => setIsDarkMode(!isDarkMode)}
      className={`fixed top-4 right-4 z-[9999] p-3 rounded-full shadow-md transition-all 
        ${isDarkMode ? 'bg-white/20 text-yellow-300' : 'bg-black/20 text-pink-700'} 
        backdrop-blur-md hover:scale-110`}
    >
      {isDarkMode ? <Sun size={22} /> : <Moon size={22} />}
    </button>
  );
};

export default ThemeToggle;
